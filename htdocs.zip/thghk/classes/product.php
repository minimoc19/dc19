

<?php 
	
	$filepath = realpath(dirname(__FILE__));

	 include_once ($filepath.'/../library/database.php');
	 include_once ($filepath.'/../helpers/format.php');
?>


<?php 

 
 class product
 {
 	
 	private $db;
 	private $fm;
 	public function __construct()
 	{
 		$this->db = new Database();
 		$this->fm = new Format();
 	}
 	public function insert_product($data,$files){
 		$productName = mysqli_real_escape_string($this->db->link, $data['productName']);
 		$brand = mysqli_real_escape_string($this->db->link, $data['brand']);
 		$category = mysqli_real_escape_string($this->db->link, $data['category']);
 		$product_desc = mysqli_real_escape_string($this->db->link, $data['product_desc']);
 		$price = mysqli_real_escape_string($this->db->link, $data['price']);
 		$type = mysqli_real_escape_string($this->db->link, $data['type']);
 		//kiem tra hinh anh va lay hinh anh cho vao folder upload
 		$permited = array('jpg', 'jpeg', 'png', 'gif'); 
 		$file_name = $_FILES['image']['name']; 
 		$file_size = $_FILES['image']['size']; 
 		$file_temp = $_FILES['image']['tmp_name'];
		$div = explode('.', $file_name); 
		$file_ext = strtolower(end($div)); 
		$unique_image = substr(md5(time()), 0, 10).'.'. $file_ext; 
		$uploaded_image = "uploads/" .$unique_image;

 		
 		if($productName=="" || $brand=="" || $category=="" || $product_desc=="" || $price=="" || $type=="" || $file_name==""  ){
 			$alert="<span class='error'>Các trường không được để trống </span>";
 			return $alert;

 		}else{
 			move_uploaded_file($file_temp,$uploaded_image);
 			$query ="INSERT INTO csdl_sanpham(productName,brandId,catId,product_desc,price,type,image) VALUES('$productName','brand','category','product_desc','$price','type','$unique_image')";
 			$result = $this->db->insert($query) ;
 			
	 			if($result){
	 				$alert = "<span class='success'>Thêm sản phẩm thành công</span>";
	 				return $alert;
	 			}else{
	 				$alert = "<span class='error'>Thêm sản phẩm không thành công</span>";
	 				return $alert;
	 			}

 			}
 		}

 	public function show_product(){
 			// $query ="SELECT p.*,c.catName, b.brandName
 			//  FROM csdl_sanpham as p,csdl_danhmuc as c,csdl_thuonghieu as b where p.catId = c.catId 
 			//  AND p.brandId = b.brandId 
 			//  order by p.productId desc";



 			// $query ="SELECT csdl_sanpham.*,csdl_danhmuc.catName, csdl_thuonghieu.brandName
 			//  FROM csdl_sanpham INNER JOIN csdl_danhmuc ON csdl_sanpham.catId = csdl_danhmuc.catId 
 			//  				   INNER JOIN csdl_thuonghieu ON csdl_sanpham.brandId = csdl_thuonghieu.brandId 
 			//  order by csdl_sanpham.productId desc";

 			$query ="SELECT * FROM csdl_sanpham order by productId desc";
 			$result = $this->db->select($query) ;
 			return $result;
 		}
 	// public function	update_product($catName,$id){
 	// 	$catName = $this->fm->validation($catName);
 	// 	$catName = mysqli_real_escape_string($this->db->link, $catName);
 	// 	$id = mysqli_real_escape_string($this->db->link, $id);


 	// 	if(empty($catName)){
 	// 		$alert="<span class='error'>Danh mục không được để trống </span>";
 	// 		return $alert;

 	// 	}else{
 	// 		$query ="UPDATE csdl_danhmuc SET catName ='$catName' WHERE catId= '$id' ";
 	// 		$result = $this->db->update($query) ;
	 		
 	// 			if($result){
	 // 				$alert = "<span class='success'>Cập nhật danh mục thành công</span>";
	 // 				return $alert;
	 // 			}else{
	 // 				$alert = "<span class='error'>Cập nhật danh mục không thành công</span>";
	 // 				return $alert;
	 // 			}

 	// 		}
 	// }
 	public function del_product($id){
 		$query ="DELETE FROM csdl_sanpham where productId = '$id' ";
 			$result = $this->db->delete($query) ;
 			if($result){
	 				$alert = "<span class='success'>Xóa sản phẩm thành công</span>";
	 				return $alert;
	 			}else{
	 				$alert = "<span class='error'>Xóa sản phẩm không thành công</span>";
	 				return $alert;
	 			}
 			
 	}
 	public function getproductbyId($id){
 			$query ="SELECT * FROM csdl_sanpham where productId = '$id' ";
 			$result = $this->db->insert($query) ;
 			return $result;
 	}


 	//end bachend

 	public function getproduct_feathered(){
 		$query ="SELECT * FROM csdl_sanpham where type = '0' ";
 			$result = $this->db->insert($query) ;
 			return $result;
 	}
 	public function getproduct_new(){
 		$query ="SELECT * FROM csdl_sanpham order by productId desc LIMIT 4 ";
 			$result = $this->db->insert($query) ;
 			return $result;
 	}
 	public function get_details($id){
 		// $query ="SELECT csdl_sanpham.*,csdl_danhmuc.catName, csdl_thuonghieu.brandName
 		// 	 FROM csdl_sanpham INNER JOIN csdl_danhmuc ON csdl_sanpham.catId = csdl_danhmuc.catId 
 		// 	 				   INNER JOIN csdl_thuonghieu ON csdl_sanpham.brandId = csdl_thuonghieu.brandId 
 		// 	 WHERE csdl_sanpham.productId='$id'";

 			$query ="SELECT * FROM csdl_sanpham WHERE productId='$id'
 			";
 			$result = $this->db->select($query) ;
 			return $result;

 	}

 	 }
 
?>