
	<div class="header_bottom">
		<div class="header_bottom_left">
			
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/d1.png" alt=""/></li>
						<li><img src="images/d2.png" alt=""/></li>
						<li><img src="images/d3.png" alt=""/></li>
						<li><img src="images/d5.png" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>